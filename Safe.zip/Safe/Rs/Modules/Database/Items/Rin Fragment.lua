return {
    ["Image"] = "rbxassetid://116131838671693",
    ["Name"] = "Rin Fragment",
    ["Category"] = "Material",
    ["Description"] = "A fragment of Rin Ghoul.",
    ["Rarity"] = "Epic",
}