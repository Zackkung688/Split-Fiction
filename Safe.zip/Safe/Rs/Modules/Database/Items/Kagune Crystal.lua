return {
    ["Image"] = "rbxassetid://88246062727173",
    ["Name"] = "Kagune Crystal",
    ["Category"] = "Material",
    ["Description"] = "A red RC crystal formed from condensed energy. Highly reactive.",
    ["Rarity"] = "Common",
}