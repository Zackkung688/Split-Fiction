return {
    ["Image"] = "rbxassetid://140173390170492",
    ["Name"] = "Rin eye",
    ["Category"] = "Material",
    ["Description"] = "A eye of Rin Ghoul.",
    ["Rarity"] = "Legendary",
}