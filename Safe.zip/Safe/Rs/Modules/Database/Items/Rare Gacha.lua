return {
    ["OnUse"] = function: 0x6975892add0432ff,
    ["Name"] = "Rare Gacha",
    ["Category"] = "Material",
    ["Usable"] = true,
    ["Description"] = "Yen x1000 (30.0%), Yen x2500 (40.0%), Yen x3000 (45.0%), Walker Scarf x1 (25.0%), Black Armor x1 (20.0%), Black Centipede x1 (2.0%), Stat refund x1 (2.0%), Clan reroll x1 (2.0%)",
    ["Rarity"] = "Rare",
}