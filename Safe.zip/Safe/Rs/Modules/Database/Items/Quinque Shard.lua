return {
    ["Image"] = "rbxassetid://103302946970438",
    ["Name"] = "Quinque Shard",
    ["Category"] = "Material",
    ["Description"] = "A refined RC-reactive crystal, harvested from a completed Quinque core.",
    ["Rarity"] = "Epic",
}