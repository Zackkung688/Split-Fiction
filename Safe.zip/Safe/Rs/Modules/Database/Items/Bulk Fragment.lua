return {
    ["Image"] = "rbxassetid://108360216893407",
    ["Name"] = "Bulk Fragment",
    ["Category"] = "Material",
    ["Description"] = "A fragment of Bulk Ghoul.",
    ["Rarity"] = "Rare",
}