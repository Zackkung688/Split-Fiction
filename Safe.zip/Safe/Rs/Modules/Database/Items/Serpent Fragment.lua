return {
    ["Image"] = "rbxassetid://97069862558174",
    ["Name"] = "Serpent Fragment",
    ["Category"] = "Material",
    ["Description"] = "A fragment of Serpent Ghoul.",
    ["Rarity"] = "Epic",
}