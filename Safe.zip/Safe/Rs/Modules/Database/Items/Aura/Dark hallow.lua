return {
    ["Rarity"] = "Mythical",
    ["Description"] = "",
    ["Name"] = "Dark hallow",
    ["Category"] = "Aura",
    ["CFrameOffset"] = 0, -3, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
    },
    ["Equippable"] = true,
    ["BodyPart"] = "HumanoidRootPart",
}