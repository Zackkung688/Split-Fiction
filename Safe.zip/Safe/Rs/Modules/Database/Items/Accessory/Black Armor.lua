return {
    ["Rarity"] = "Rare",
    ["Description"] = "Kaneki’s armor symbolizing endurance, pain, and overwhelming resolve.",
    ["Name"] = "Black Armor",
    ["Category"] = "Accessory",
    ["CFrameOffset"] = 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Durability"] = 40,
        ["Stamina"] = 5,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "UpperTorso",
}