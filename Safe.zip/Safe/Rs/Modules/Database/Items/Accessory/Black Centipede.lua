return {
    ["Rarity"] = "Mythical",
    ["Clothing"] = true,
    ["Description"] = "Black Centipede attire once worn by Ken Kaneki. It embodies pain, rage, and overwhelming power born from endless suffering.",
    ["Name"] = "Black Centipede",
    ["Category"] = "Accessory",
    ["CFrameOffset"] = 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Durability"] = 30,
        ["Speed"] = 35,
        ["Damage"] = 35,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "UpperTorso",
}