return {
    ["Rarity"] = "Rare",
    ["Description"] = "A legendary red sweater infused with mystical energy. Those who wear it gain enhanced durability, stamina, and swift movement in battle.",
    ["Image"] = "rbxassetid://70610953114837",
    ["Name"] = "Christmas scarf",
    ["Category"] = "Accessory",
    ["CFrameOffset"] = 0, 0.100000001, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Durability"] = 20,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "UpperTorso",
}