return {
    ["Rarity"] = "Mythical",
    ["Clothing"] = true,
    ["Description"] = "A long white cloak once worn by Kishou Arima. It carries the calm, precision, and power of the CCG’s strongest investigator.",
    ["Image"] = "rbxassetid://109550015910412",
    ["Name"] = "Reaper's cloak",
    ["Category"] = "Accessory",
    ["CFrameOffset"] = 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Stamina"] = 10,
        ["Speed"] = 30,
        ["Damage"] = 45,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "UpperTorso",
}