return {
    ["Rarity"] = "Rare",
    ["Clothing"] = true,
    ["Description"] = "A clean white uniform that grants balanced defense and movement.",
    ["Name"] = "White Uniform",
    ["Category"] = "Accessory",
    ["CFrameOffset"] = 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Durability"] = 10,
        ["Speed"] = 10,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "UpperTorso",
}