return {
    ["Rarity"] = "Epic",
    ["Clothing"] = true,
    ["Description"] = "Red Aogiri uniform worn by members of the Aogiri Tree. It symbolizes rebellion, bloodshed, and unwavering loyalty to their cause.",
    ["Name"] = "Red Abyss",
    ["Category"] = "Accessory",
    ["CFrameOffset"] = 0, 0, 4, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Speed"] = 25,
        ["Damage"] = 25,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "UpperTorso",
}