return {
    ["Rarity"] = "Epic",
    ["Clothing"] = true,
    ["Description"] = "A legendary red sweater infused with mystical energy. Those who wear it gain enhanced durability, stamina, and swift movement in battle.",
    ["Image"] = "rbxassetid://130149184324750",
    ["Name"] = "Green Sweater",
    ["Category"] = "Accessory",
    ["CFrameOffset"] = 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Durability"] = 30,
        ["Speed"] = 8,
        ["Stamina"] = 20,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "UpperTorso",
}