return {
    ["Rarity"] = "Common",
    ["Description"] = "Kaneki’s armor symbolizing endurance, pain, and overwhelming resolve.",
    ["Name"] = "Walker Scarf",
    ["Category"] = "Accessory",
    ["CFrameOffset"] = 0, 0.600000024, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Speed"] = 5,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "UpperTorso",
}