return {
    ["Name"] = "Flower",
    ["Category"] = "Material",
    ["Description"] = "",
    ["Rarity"] = "Common",
}