return {
    ["Rarity"] = "Uncommon",
    ["Clothing"] = false,
    ["OnEquip"] = function: 0x81e72644e53fbbef,
    ["Description"] = "A rare party hat that represents celebration, joy, and standing out from the crowd.",
    ["Name"] = "Party hat",
    ["Category"] = "Hat",
    ["CFrameOffset"] = -0.0130000003, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
    },
    ["Equippable"] = true,
    ["BodyPart"] = "Head",
}