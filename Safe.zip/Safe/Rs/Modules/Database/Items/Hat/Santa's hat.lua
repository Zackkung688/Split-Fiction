return {
    ["Rarity"] = "Legendary",
    ["Clothing"] = false,
    ["Description"] = "A classic Santa’s hat that spreads warmth and holiday cheer. Worn during the festive season to bring joy, luck, and a touch of Christmas magic.",
    ["Image"] = "rbxassetid://82002751906539",
    ["Name"] = "Santa's hat",
    ["Category"] = "Hat",
    ["CFrameOffset"] = -0.100000001, 1, 0.0500000007, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Durability"] = 30,
        ["Speed"] = 7,
        ["Stamina"] = 20,
        ["Damage"] = 7,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "Head",
}