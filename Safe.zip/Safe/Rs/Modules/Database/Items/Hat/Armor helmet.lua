return {
    ["Rarity"] = "Uncommon",
    ["Clothing"] = false,
    ["Description"] = "A basic armor helmet that provides protection and a small boost to combat strength.",
    ["Image"] = "rbxassetid://86641062871041",
    ["Name"] = "Armor helmet",
    ["Category"] = "Hat",
    ["CFrameOffset"] = 0, 0.400000006, 0.0399999991, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Durability"] = 5,
        ["Damage"] = 3,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "Head",
}