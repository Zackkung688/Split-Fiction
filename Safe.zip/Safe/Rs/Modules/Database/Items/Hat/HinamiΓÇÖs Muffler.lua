return {
    ["Rarity"] = "Common",
    ["Clothing"] = false,
    ["Description"] = "A soft muffler once worn by Hinami Fueguchi. It carries warmth, comfort, and the memory of those she loved.",
    ["Image"] = "rbxassetid://121802584085675",
    ["Name"] = "Hinami’s Muffler",
    ["Category"] = "Hat",
    ["CFrameOffset"] = 0, 0.75, 0, -1, 0, 8.74227766e-08, 0, 1, 0, -8.74227766e-08, 0, -1,
    ["Buffs"] = {
        ["Durability"] = 10,
        ["Stamina"] = 5,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "Head",
}