return {
    ["Rarity"] = "Mythical",
    ["Clothing"] = false,
    ["Description"] = "The signature glasses of Kishou Arima. They reflect his sharp vision, calm focus, and unmatched skill on the battlefield.",
    ["Image"] = "rbxassetid://127436166280499",
    ["Name"] = "Arima's Glasses",
    ["Category"] = "Face",
    ["CFrameOffset"] = 0, 0.200000003, -0.550000012, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Speed"] = 45,
        ["Damage"] = 60,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "Head",
}