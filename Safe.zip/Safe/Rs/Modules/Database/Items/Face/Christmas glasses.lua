return {
    ["Rarity"] = "Rare",
    ["Clothing"] = false,
    ["Description"] = "Rare festive glasses that enhance vision, speed, and combat power during the holiday season.",
    ["Image"] = "rbxassetid://125101208400305",
    ["Name"] = "Christmas glasses",
    ["Category"] = "Face",
    ["CFrameOffset"] = -0.00600000005, 0.400000006, -0.25, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Stamina"] = 10,
        ["Speed"] = 3,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "Head",
}