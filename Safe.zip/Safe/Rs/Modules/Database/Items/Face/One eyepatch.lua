return {
    ["Rarity"] = "Uncommon",
    ["Description"] = "Sleek one-eyed eyepatch symbolizing resilience, focus, and hidden strength. Worn by those who have survived the battlefield",
    ["Name"] = "One eyepatch",
    ["Category"] = "Face",
    ["CFrameOffset"] = 0, 0, -0.280000001, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Durability"] = 7,
        ["Stamina"] = 5,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "Head",
}