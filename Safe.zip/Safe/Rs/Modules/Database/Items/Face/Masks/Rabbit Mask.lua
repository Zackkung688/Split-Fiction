return {
    ["Description"] = "A rabbit mask with a mischievous grin, symbolizing speed, agility, and elusiveness.",
    ["Image"] = "rbxassetid://80373452444751",
    ["Name"] = "Rabbit",
    ["Category"] = "Face",
    ["Price"] = 0,
    ["Buffs"] = {
        ["Stamina"] = 5,
        ["Speed"] = 20,
    },
    ["Equippable"] = true,
    ["Rarity"] = "Uncommon",
}