return {
    ["Image"] = "rbxassetid://97060285069623",
    ["Name"] = "Raven",
    ["Category"] = "Face",
    ["Description"] = "A sleek black raven mask symbolizing cunning, agility, and deadly intent. Perfect for hunters who move unseen.",
    ["Buffs"] = {
        ["Stamina"] = 50,
        ["Damage"] = 35,
    },
    ["Equippable"] = true,
    ["Rarity"] = "Epic",
}