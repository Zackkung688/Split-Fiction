return {
    ["Rarity"] = "Legendary",
    ["Clothing"] = false,
    ["Description"] = "Mask worn by Noro, symbolizing silence, hunger, and terrifying endurance",
    ["Name"] = "Noro Mask",
    ["Category"] = "Face",
    ["CFrameOffset"] = 0, 0, -0.550000012, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Stamina"] = 25,
        ["Speed"] = 25,
        ["Damage"] = 20,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "Head",
}