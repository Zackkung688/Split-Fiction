return {
    ["Image"] = "rbxassetid://130028937304960",
    ["Name"] = "Eyepatch",
    ["Category"] = "Face",
    ["Description"] = "A black leather mask with a single eyepatch, worn by Kaneki. Symbol of pain, struggle, and hidden power.",
    ["Buffs"] = {
        ["Durability"] = 10,
        ["Damage"] = 45,
    },
    ["Equippable"] = true,
    ["Rarity"] = "Rare",
}