return {
    ["Description"] = "A mask worn by a gourmet ghoul, symbolizing refined taste and deadly strength. Only the strongest survive its wearer's appetite.",
    ["Image"] = "rbxassetid://116672129964819",
    ["Name"] = "Gourmet",
    ["Category"] = "Face",
    ["Price"] = 200000,
    ["Buffs"] = {
        ["Stamina"] = 5,
        ["Damage"] = 8,
    },
    ["Equippable"] = true,
    ["Rarity"] = "Common",
}