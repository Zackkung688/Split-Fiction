return {
    ["Rarity"] = "Uncommon",
    ["Price"] = 250000,
    ["Description"] = "A product of failed experiments, with eyes that pierce fear itself.",
    ["Name"] = "Red Iris",
    ["Category"] = "Face",
    ["CFrameOffset"] = 0, 0, -0.469999999, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Durability"] = 15,
        ["Stamina"] = 10,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "Head",
}