return {
    ["Description"] = "A dark, wolf-like mask said to embody the fury of a beast within. Those who wear it channel their rage into raw, unrelenting power.",
    ["Image"] = "rbxassetid://94535421453193",
    ["Name"] = "Blackdog",
    ["Category"] = "Face",
    ["Price"] = 200000,
    ["Buffs"] = {
        ["Durability"] = 5,
        ["Damage"] = 8,
    },
    ["Equippable"] = true,
    ["Rarity"] = "Common",
}