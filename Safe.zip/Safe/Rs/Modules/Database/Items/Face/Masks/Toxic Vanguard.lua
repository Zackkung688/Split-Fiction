return {
    ["Rarity"] = "Uncommon",
    ["Price"] = 250000,
    ["Description"] = "Protective gear for those who enter zones filled with deadly gas.",
    ["Name"] = "Toxic Vanguard",
    ["Category"] = "Face",
    ["CFrameOffset"] = 0, 0, -0.479999989, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Durablity"] = 15,
        ["Damage"] = 7,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "Head",
}