return {
    ["Description"] = "A terrifying ape-like mask radiating chaos and strength. Worn by those who embrace their wild side.",
    ["Image"] = "rbxassetid://128192074458968",
    ["Name"] = "Devil Ape",
    ["Category"] = "Face",
    ["Price"] = 500000,
    ["Buffs"] = {
        ["Speed"] = 6,
        ["Damage"] = 8,
    },
    ["Equippable"] = true,
    ["Rarity"] = "Common",
}