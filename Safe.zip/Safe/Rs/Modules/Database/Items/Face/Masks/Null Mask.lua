return {
    ["Rarity"] = "Common",
    ["Price"] = 100000,
    ["Description"] = "A mask worn by a silent enforcer who leaves no trace behind.",
    ["Name"] = "Null Mask",
    ["Category"] = "Face",
    ["CFrameOffset"] = 0, 0, -0.460000008, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Damage"] = 10,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "Head",
}