return {
    ["Rarity"] = "Uncommon",
    ["Price"] = 300000,
    ["Description"] = "A twisted smile that hides madness and cruelty.",
    ["Name"] = "Mockery",
    ["Category"] = "Face",
    ["CFrameOffset"] = 0, 0, -0.379999995, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    ["Buffs"] = {
        ["Speed"] = 12,
        ["Damage"] = 12,
    },
    ["Equippable"] = true,
    ["BodyPart"] = "Head",
}