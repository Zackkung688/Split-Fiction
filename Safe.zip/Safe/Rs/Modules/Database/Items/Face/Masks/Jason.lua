return {
    ["Image"] = "rbxassetid://83556299860387",
    ["Name"] = "Jason",
    ["Category"] = "Face",
    ["Description"] = "A white mask with a twisted grin, worn by Jason. Radiates cruelty and madness.",
    ["Buffs"] = {
        ["Durability"] = 20,
        ["Stamina"] = 15,
        ["Damage"] = 30,
    },
    ["Equippable"] = true,
    ["Rarity"] = "Legendary",
}