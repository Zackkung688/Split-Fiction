return {
    ["OnUse"] = function: 0xc511f66c28167fdf,
    ["Name"] = "Legend Gacha",
    ["Category"] = "Material",
    ["Usable"] = true,
    ["Description"] = "Yen x1000 (10.0%), Yen x2500 (15.0%), Yen x3000 (25.0%), Walker Scarf x1 (40.0%), Black Armor x1 (35.0%), Black Centipede x1 (8.0%), Stat refund x1 (8.0%), Clan reroll x1 (8.0%)",
    ["Rarity"] = "Legendary",
}