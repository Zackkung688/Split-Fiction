return {
    ["OnUse"] = function: 0x1eaa1af5ec3f998f,
    ["Name"] = "Gacha",
    ["Category"] = "Material",
    ["Usable"] = true,
    ["Description"] = "Yen x1000 (80.0%), Yen x2500 (50.0%), Yen x3000 (30.0%), Walker Scarf x1 (10.0%), Black Armor x1 (7.0%), Black Centipede x1 (0.5%), Stat refund x1 (0.5%), Clan reroll x1 (0.5%)",
    ["Rarity"] = "Common",
}