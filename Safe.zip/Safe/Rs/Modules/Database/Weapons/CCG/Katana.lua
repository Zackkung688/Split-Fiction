return {
    ["Type"] = "Unknown",
    ["HitEffect"] = "BloodSlash",
    ["Animations"] = {
        ["M3"] = 107285175088791,
        ["M2"] = 114302659922997,
        ["Idle"] = 108908488262922,
        ["M4"] = 91925080118038,
        ["M1"] = 118163671371723,
        ["Run"] = 102060045967695,
    },
    ["AlwaysInShop"] = true,
    ["AttackDelay"] = 0.4,
    ["Image"] = "rbxassetid://108272396566566",
    ["Weld"] = {
        ["Target"] = "RightHand",
        ["Offset"] = 0, 0, 0, 1.91068547e-15, -4.37113883e-08, 1, -1, -4.37113883e-08, 0, 4.37113883e-08, -1, -4.37113883e-08,
    },
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -2.5, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Damage"] = 10,
        ["Size"] = 10, 5, 8,
    },
    ["AttackSound"] = "SwordSwing",
    ["MaxMastery"] = 300,
    ["Rarity"] = "Common",
    ["Buy"] = {
        ["ProductID"] = 3498034934,
        ["Materials"] = {
        },
        ["Yen"] = 25000,
    },
}