return {
    ["Type"] = "Bikaku",
    ["HitEffect"] = "BloodSplash",
    ["Animations"] = {
        ["M3"] = 116108428639400,
        ["M2"] = 115851831339130,
        ["Idle"] = 86356715913129,
        ["M4"] = 87499033782649,
        ["M1"] = 100722783465410,
        ["Run"] = 134079828019619,
        ["Walk"] = 103323191136024,
    },
    ["AttackDelay"] = 0.45,
    ["Image"] = "rbxassetid://71600794827793",
    ["Weld"] = {
        ["Target"] = "RightHand",
        ["Offset"] = -0.115999997, -0.0979999974, -0.0869999975, 1.91068547e-15, -4.37113883e-08, -1, -1, -4.37113883e-08, 0, -4.37113883e-08, 1, -4.37113883e-08,
    },
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -5, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Damage"] = 12,
        ["Size"] = 12, 5, 12,
    },
    ["AttackSound"] = "SwordSwing",
    ["MaxMastery"] = 300,
    ["Rarity"] = "Rare",
    ["Buy"] = {
        ["ProductID"] = 3495389226,
        ["Materials"] = {
            ["Bulk Fragment"] = 10,
            ["Serpent Fragment"] = 5,
            ["Quinque Shard"] = 10,
        },
        ["Yen"] = 1000000,
    },
}