return {
    ["Type"] = "Koukaku",
    ["HitEffect"] = "BloodSplash",
    ["Animations"] = {
        ["M3"] = 120860506320400,
        ["M2"] = 124889071456356,
        ["Idle"] = 96408760566732,
        ["M4"] = 121646727732659,
        ["M1"] = 83774604668548,
        ["Run"] = 133663533340528,
        ["Walk"] = 83432213538212,
    },
    ["AttackDelay"] = 0.4,
    ["Image"] = "rbxassetid://110052659341586",
    ["Weld"] = {
        ["Target"] = "RightHand",
        ["Offset"] = 0, 0, 0, 1, -0, 0, 0, -4.37113883e-08, 1, 0, -1, -4.37113883e-08,
    },
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -5, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Damage"] = 20,
        ["Size"] = 10, 5, 12,
    },
    ["AttackSound"] = "Woosh",
    ["MaxMastery"] = 300,
    ["Rarity"] = "Uncommon",
    ["Buy"] = {
        ["ProductID"] = 3495387651,
        ["Materials"] = {
            ["Quinque Shard"] = 5,
        },
        ["Yen"] = 100000,
    },
}