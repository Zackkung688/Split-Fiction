return {
    ["StaminaUsed"] = 35,
    ["LevelRequired"] = 1,
    ["Name"] = "Death Swing",
    ["Keybind"] = Enum.KeyCode.Z,
    ["MasteryRequired"] = 0,
    ["Cooldown"] = 7,
    ["New"] = function: 0xf601b27a1dfdd0ef,
}