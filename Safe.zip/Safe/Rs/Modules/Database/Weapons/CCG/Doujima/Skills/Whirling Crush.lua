return {
    ["StaminaUsed"] = 40,
    ["LevelRequired"] = 150,
    ["Name"] = "Whirling Crush",
    ["Keybind"] = Enum.KeyCode.V,
    ["MasteryRequired"] = 200,
    ["Cooldown"] = 10,
    ["New"] = function: 0xd4cfee651bc48aaf,
}