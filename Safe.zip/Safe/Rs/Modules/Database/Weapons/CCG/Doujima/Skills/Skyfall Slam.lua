return {
    ["StaminaUsed"] = 35,
    ["LevelRequired"] = 125,
    ["Name"] = "Skyfall Slam",
    ["Keybind"] = Enum.KeyCode.C,
    ["MasteryRequired"] = 150,
    ["Cooldown"] = 12,
    ["New"] = function: 0x8b8daf966de436ef,
}