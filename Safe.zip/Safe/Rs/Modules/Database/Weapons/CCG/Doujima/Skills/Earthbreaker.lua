return {
    ["StaminaUsed"] = 45,
    ["LevelRequired"] = 50,
    ["Name"] = "Earthbreaker",
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 75,
    ["Cooldown"] = 10,
    ["New"] = function: 0x2e4aac80f784e72f,
}