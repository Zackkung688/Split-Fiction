return {
    ["Loop"] = function: 0x6e3aafa0c4076caf,
    ["Stop"] = function: 0xadc18e1c16d555ef,
    ["StopAll"] = function: 0xcc9e8f69a2a83b2f,
}