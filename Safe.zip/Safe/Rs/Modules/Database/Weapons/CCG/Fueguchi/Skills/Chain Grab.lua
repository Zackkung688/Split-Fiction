return {
    ["StaminaUsed"] = 35,
    ["LevelRequired"] = 50,
    ["Name"] = "Chain Grab",
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 75,
    ["Cooldown"] = 12,
    ["New"] = function: 0x73700c0761de986f,
}