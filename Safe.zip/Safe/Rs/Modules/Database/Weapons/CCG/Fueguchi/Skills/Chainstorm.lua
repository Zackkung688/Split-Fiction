return {
    ["StaminaUsed"] = 40,
    ["LevelRequired"] = 200,
    ["Name"] = "Chainstorm",
    ["Keybind"] = Enum.KeyCode.V,
    ["MasteryRequired"] = 250,
    ["Cooldown"] = 17,
    ["New"] = function: 0x0cc2b98e0d6336ef,
}