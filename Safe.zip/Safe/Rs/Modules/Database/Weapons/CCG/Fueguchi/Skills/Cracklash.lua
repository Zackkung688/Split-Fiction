return {
    ["StaminaUsed"] = 35,
    ["LevelRequired"] = 1,
    ["Name"] = "Cracklash",
    ["Keybind"] = Enum.KeyCode.Z,
    ["MasteryRequired"] = 0,
    ["Cooldown"] = 10,
    ["New"] = function: 0xa6ad7bbe9a1296df,
}