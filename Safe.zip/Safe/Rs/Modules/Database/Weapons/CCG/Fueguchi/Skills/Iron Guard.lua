return {
    ["LevelRequired"] = 125,
    ["Keybind"] = Enum.KeyCode.C,
    ["MasteryRequired"] = 150,
    ["StaminaUsed"] = 40,
    ["Hold"] = true,
    ["LimitHoldDuration"] = 4,
    ["Name"] = "Iron Guard",
    ["Cooldown"] = 15,
    ["New"] = function: 0xd838c6ba66740d6f,
}