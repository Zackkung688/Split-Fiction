return {
    ["Type"] = "Ukaku",
    ["HitEffect"] = "BloodSplash",
    ["Animations"] = {
        ["M3"] = 85235463755403,
        ["M2"] = 139097090584127,
        ["Idle"] = 115416911835104,
        ["M4"] = 133127609091011,
        ["M1"] = 98442566082535,
        ["Run"] = 125745649383137,
        ["Walk"] = 86800935159625,
    },
    ["OnM1"] = function: 0xce2e79428c4848df,
    ["AttackSound"] = "Woosh",
    ["AttackDelay"] = 0.4,
    ["Image"] = "rbxassetid://93829176816459",
    ["Weld"] = {
        ["Target"] = "RightHand",
        ["Offset"] = 0.0270000007, 1.61500001, -0.0219999999, -1, 0, 8.74227766e-08, 0, 1, 0, -8.74227766e-08, 0, -1,
    },
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -5, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Damage"] = 20,
        ["Size"] = 10, 5, 12,
    },
    ["Stacks"] = {
        ["StackTest"] = {
            ["Max"] = 8,
            ["BarColor"] = 1, 0.921569, 0.313726,
            ["ValueType"] = "NumberValue",
        },
    },
    ["MaxMastery"] = 300,
    ["Rarity"] = "Rare",
    ["Buy"] = {
        ["ProductID"] = 3498038656,
        ["Materials"] = {
            ["Bulk Fragment"] = 15,
            ["Serpent Fragment"] = 10,
            ["Quinque Shard"] = 10,
        },
        ["Yen"] = 1500000,
    },
}