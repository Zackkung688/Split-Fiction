return {
    ["Type"] = "Koukaku",
    ["HitEffect"] = "BloodSlash",
    ["Animations"] = {
        ["M3"] = 103200778878235,
        ["M2"] = 86472646302574,
        ["Idle"] = 140371296061312,
        ["M4"] = 129055918595744,
        ["M1"] = 117440197029548,
        ["Run"] = 127748619958696,
        ["Walk"] = 109562837086590,
    },
    ["AttackDelay"] = 0.4,
    ["Image"] = "rbxassetid://100749642418954",
    ["Weld"] = {
        ["Target"] = "RightHand",
        ["Offset"] = -0.0960000008, -0.150000006, 0.882000029, 1.91068547e-15, -4.37113883e-08, 1, -1, -4.37113883e-08, 0, 4.37113883e-08, -1, -4.37113883e-08,
    },
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -5, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Damage"] = 11,
        ["Size"] = 10, 5, 12,
    },
    ["AttackSound"] = "SwordSwing",
    ["MaxMastery"] = 400,
    ["Rarity"] = "Legendary",
    ["Buy"] = {
        ["ProductID"] = 3495390083,
        ["Materials"] = {
            ["Rin Fragment"] = 20,
            ["Rin eye"] = 3,
            ["Bulk Fragment"] = 20,
            ["Serpent Fragment"] = 15,
            ["Quinque Shard"] = 20,
        },
        ["Yen"] = 3000000,
    },
}