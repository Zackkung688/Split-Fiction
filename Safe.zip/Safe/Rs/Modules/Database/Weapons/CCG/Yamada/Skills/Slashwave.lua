return {
    ["LevelRequired"] = 175,
    ["Keybind"] = Enum.KeyCode.V,
    ["MasteryRequired"] = 225,
    ["StaminaUsed"] = 45,
    ["Hold"] = true,
    ["LimitHoldDuration"] = 2,
    ["Name"] = "Slashwave",
    ["Cooldown"] = 8,
    ["New"] = function: 0xfe21a9d71a6d074f,
}