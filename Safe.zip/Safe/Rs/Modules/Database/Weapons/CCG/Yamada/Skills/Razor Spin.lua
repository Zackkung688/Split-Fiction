return {
    ["StaminaUsed"] = 45,
    ["LevelRequired"] = 100,
    ["Name"] = "Razor Spin",
    ["Keybind"] = Enum.KeyCode.C,
    ["MasteryRequired"] = 125,
    ["Cooldown"] = 20,
    ["New"] = function: 0xfade87227ca259cf,
}