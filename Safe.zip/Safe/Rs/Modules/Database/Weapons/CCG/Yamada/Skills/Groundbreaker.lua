return {
    ["StaminaUsed"] = 25,
    ["LevelRequired"] = 50,
    ["Name"] = "Groundbreaker",
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 75,
    ["Cooldown"] = 7,
    ["New"] = function: 0x21bc2d64a87a349f,
}