return {
    ["LevelRequired"] = 1,
    ["Keybind"] = Enum.KeyCode.Z,
    ["MasteryRequired"] = 0,
    ["StaminaUsed"] = 25,
    ["Hold"] = true,
    ["LimitHoldDuration"] = 2,
    ["Name"] = "Blink Slash",
    ["Cooldown"] = 10,
    ["New"] = function: 0x23d458cd8305e96f,
}