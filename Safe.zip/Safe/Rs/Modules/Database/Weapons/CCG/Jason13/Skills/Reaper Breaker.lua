return {
    ["LevelRequired"] = 25,
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 50,
    ["StaminaUsed"] = 25,
    ["Hold"] = true,
    ["LimitHoldDuration"] = 5,
    ["Name"] = "Reaper Breaker",
    ["Cooldown"] = 14,
    ["New"] = function: 0x82200f4645d707ef,
}