return {
    ["Loop"] = function: 0x35e6ac934ea628ef,
    ["Stop"] = function: 0xf60bc90bac35482f,
    ["StopAll"] = function: 0x27dece7a22b9796f,
}