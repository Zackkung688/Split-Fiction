return {
    ["StaminaUsed"] = 30,
    ["LevelRequired"] = 1,
    ["Name"] = "Crimson Splitter",
    ["Keybind"] = Enum.KeyCode.Z,
    ["MasteryRequired"] = 0,
    ["Cooldown"] = 10,
    ["New"] = function: 0xe19aa6e84bb2386f,
}