return {
    ["Type"] = "Rinkaku",
    ["HitEffect"] = "BloodSplash",
    ["Animations"] = {
        ["M3"] = 138512291706685,
        ["M2"] = 84961044314000,
        ["Idle"] = 135491412949743,
        ["M4"] = 95403624252131,
        ["M1"] = 125829112717301,
        ["Run"] = 116114964978337,
        ["Walk"] = 106795534159817,
    },
    ["Buy"] = {
        ["Materials"] = {
            ["Quinque Shard"] = 10,
            ["Bulk Fragment"] = 50,
            ["Serpent Fragment"] = 35,
            ["Rin Fragment"] = 25,
        },
        ["Yen"] = 2000000,
    },
    ["AttackDelay"] = 0.2,
    ["Image"] = "rbxassetid://121547843744907",
    ["Weld"] = {
        ["Target"] = "RightHand",
        ["Offset"] = 0.00600000005, -0.160999998, 0.0419999994, 1, -0, 0, 0, -4.37113883e-08, 1, 0, -1, -4.37113883e-08,
    },
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -2.5, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Damage"] = 12,
        ["Size"] = 10, 5, 12,
    },
    ["AttackSound"] = "SwordSwing",
    ["MaxMastery"] = 300,
    ["Rarity"] = "Legendary",
    ["DevOnly"] = true,
}