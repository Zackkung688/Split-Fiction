return {
    ["StaminaUsed"] = 45,
    ["LevelRequired"] = 135,
    ["Name"] = "Bloodwhirl",
    ["Keybind"] = Enum.KeyCode.C,
    ["MasteryRequired"] = 150,
    ["Cooldown"] = 15,
    ["New"] = function: 0x41f6ba89927a15ef,
}