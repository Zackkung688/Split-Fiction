return {
    ["StaminaUsed"] = 0,
    ["LevelRequired"] = 250,
    ["Name"] = "Kura Split",
    ["Keybind"] = Enum.KeyCode.V,
    ["MasteryRequired"] = 300,
    ["Cooldown"] = 1,
    ["New"] = function: 0xa011cb52837f236f,
}