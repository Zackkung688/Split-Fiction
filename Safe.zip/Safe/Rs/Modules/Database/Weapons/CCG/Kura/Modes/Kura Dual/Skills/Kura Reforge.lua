return {
    ["StaminaUsed"] = 0,
    ["LevelRequired"] = 250,
    ["Name"] = "Kura Reforge",
    ["Keybind"] = Enum.KeyCode.V,
    ["MasteryRequired"] = 300,
    ["Cooldown"] = 1,
    ["New"] = function: 0x299fe8fa2d67b2ef,
}