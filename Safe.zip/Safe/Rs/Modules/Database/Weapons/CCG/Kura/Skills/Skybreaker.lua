return {
    ["LevelRequired"] = 75,
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 75,
    ["StaminaUsed"] = 35,
    ["Hold"] = true,
    ["LimitHoldDuration"] = 3,
    ["Name"] = "Skybreaker",
    ["Cooldown"] = 9,
    ["New"] = function: 0xd26332b38583f9ef,
}