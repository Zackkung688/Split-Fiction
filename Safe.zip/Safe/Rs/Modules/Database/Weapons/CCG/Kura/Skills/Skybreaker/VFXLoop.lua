return {
    ["Loop"] = function: 0xf47cc3cb401d97af,
    ["Stop"] = function: 0xb50df3fb0d994eef,
    ["StopAll"] = function: 0x0664e3b36b460a2f,
}