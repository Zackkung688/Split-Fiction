return {
    ["AttackDelay"] = 0.35,
    ["OnDeactivate"] = function: 0x6cad75bd90979b0f,
    ["HitEffect"] = "BloodSlash",
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -5, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Damage"] = 7,
        ["Size"] = 10, 5, 12,
    },
    ["Animations"] = {
        ["M3"] = 120552443513401,
        ["M2"] = 136329615181097,
        ["Idle"] = 116523382927991,
        ["M4"] = 109151290859639,
        ["M1"] = 85359966335896,
        ["Run"] = 99829471249288,
        ["Walk"] = 78158378118659,
    },
    ["OnSetup"] = function: 0xa30b09154b56776f,
    ["Weld"] = {
        ["Target"] = "RightHand",
        ["Offset"] = -0.0179999992, -0.150999993, -3.86500001, 1.91068547e-15, 4.37113883e-08, -1, 1, -4.37113883e-08, 0, -4.37113883e-08, -1, -4.37113883e-08,
    },
    ["AttackSound"] = "SwordSwing",
}