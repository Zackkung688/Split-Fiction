return {
    ["LevelRequired"] = 125,
    ["Keybind"] = Enum.KeyCode.Z,
    ["MasteryRequired"] = 145,
    ["StaminaUsed"] = 45,
    ["Hold"] = true,
    ["LimitHoldDuration"] = 2,
    ["Name"] = "Twin Wave",
    ["Cooldown"] = 6,
    ["New"] = function: 0xc4e4f9ba2eab8e6f,
}