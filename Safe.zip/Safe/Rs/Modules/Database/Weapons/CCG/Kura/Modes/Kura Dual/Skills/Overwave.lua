return {
    ["StaminaUsed"] = 45,
    ["LevelRequired"] = 225,
    ["Name"] = "Overwave",
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 250,
    ["Cooldown"] = 15,
    ["New"] = function: 0x6231ca4e86519ecf,
}