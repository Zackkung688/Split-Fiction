return {
    ["LevelRequired"] = 1,
    ["Keybind"] = Enum.KeyCode.Z,
    ["MasteryRequired"] = 0,
    ["StaminaUsed"] = 20,
    ["Hold"] = true,
    ["LimitHoldDuration"] = 2,
    ["Name"] = "Crimson Arc",
    ["Cooldown"] = 6,
    ["New"] = function: 0x369779d9d4aaf41f,
}