return {
    ["StaminaUsed"] = 30,
    ["LevelRequired"] = 35,
    ["Name"] = "Overcharge Rampage",
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 55,
    ["Cooldown"] = 12,
    ["New"] = function: 0x0a9d4442ed7a736f,
}