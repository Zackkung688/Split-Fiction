return {
    ["LevelRequired"] = 175,
    ["Keybind"] = Enum.KeyCode.V,
    ["MasteryRequired"] = 225,
    ["StaminaUsed"] = 45,
    ["Name"] = "Stormbreaker Burst",
    ["LimitHoldDuration"] = 1,
    ["Hold"] = true,
    ["MaxRange"] = 150,
    ["Cooldown"] = 30,
    ["New"] = function: 0x1795b4982ffd623f,
}