return {
    ["StaminaUsed"] = 35,
    ["LevelRequired"] = 75,
    ["Name"] = "Apex Awakening",
    ["Keybind"] = Enum.KeyCode.C,
    ["MasteryRequired"] = 110,
    ["Cooldown"] = 40,
    ["New"] = function: 0x859a291e797cbc2f,
}