return {
    ["StaminaUsed"] = 35,
    ["LevelRequired"] = 1,
    ["Name"] = "Plasma Fields",
    ["Keybind"] = Enum.KeyCode.Z,
    ["MasteryRequired"] = 0,
    ["Cooldown"] = 15,
    ["New"] = function: 0x2d16f14ee009946f,
}