return {
    ["StaminaUsed"] = 35,
    ["LevelRequired"] = 1,
    ["Name"] = "Whirlwind Slash",
    ["Keybind"] = Enum.KeyCode.Z,
    ["MasteryRequired"] = 0,
    ["Cooldown"] = 8,
    ["New"] = function: 0x55b006d67427d1df,
}