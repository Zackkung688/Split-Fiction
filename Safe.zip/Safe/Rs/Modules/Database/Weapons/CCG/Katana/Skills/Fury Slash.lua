return {
    ["StaminaUsed"] = 50,
    ["LevelRequired"] = 50,
    ["Name"] = "Fury Slash",
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 75,
    ["Cooldown"] = 10,
    ["New"] = function: 0x836a1d3a465ce6af,
}