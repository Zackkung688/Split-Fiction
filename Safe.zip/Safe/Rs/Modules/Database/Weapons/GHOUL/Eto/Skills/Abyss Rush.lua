return {
    ["StaminaUsed"] = 45,
    ["LevelRequired"] = 75,
    ["Name"] = "Abyss Rush",
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 125,
    ["Cooldown"] = 10,
    ["New"] = function: 0x280cff7916a2bc6f,
}