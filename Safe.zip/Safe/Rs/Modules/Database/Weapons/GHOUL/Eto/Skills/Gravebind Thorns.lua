return {
    ["StaminaUsed"] = 45,
    ["LevelRequired"] = 200,
    ["Name"] = "Gravebind Thorns",
    ["Keybind"] = Enum.KeyCode.V,
    ["MasteryRequired"] = 250,
    ["Cooldown"] = 18,
    ["New"] = function: 0x2944be11ad190eef,
}