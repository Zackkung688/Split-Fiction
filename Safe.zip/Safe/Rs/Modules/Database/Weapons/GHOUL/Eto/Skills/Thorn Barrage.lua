return {
    ["LevelRequired"] = 165,
    ["Keybind"] = Enum.KeyCode.C,
    ["MasteryRequired"] = 200,
    ["StaminaUsed"] = 45,
    ["Hold"] = true,
    ["LimitHoldDuration"] = 4,
    ["Name"] = "Thorn Barrage",
    ["Cooldown"] = 10,
    ["New"] = function: 0x0259f6c560a6ce6f,
}