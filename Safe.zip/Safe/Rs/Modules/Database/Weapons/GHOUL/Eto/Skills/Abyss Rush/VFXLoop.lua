return {
    ["Loop"] = function: 0xf227b84eae76a0cf,
    ["Stop"] = function: 0x0786e9d7644eebef,
    ["StopAll"] = function: 0xf4037d03df5f9eef,
}