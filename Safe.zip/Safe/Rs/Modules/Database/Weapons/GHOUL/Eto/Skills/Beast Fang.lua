return {
    ["StaminaUsed"] = 25,
    ["LevelRequired"] = 1,
    ["Name"] = "Beast Fang",
    ["Keybind"] = Enum.KeyCode.Z,
    ["MasteryRequired"] = 0,
    ["Cooldown"] = 6,
    ["New"] = function: 0x956b7b332ce5b76f,
}