return {
    ["StaminaUsed"] = 25,
    ["LevelRequired"] = 25,
    ["Name"] = "Crushing Tail",
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 45,
    ["Cooldown"] = 7,
    ["New"] = function: 0xde9ef16420e8d06f,
}