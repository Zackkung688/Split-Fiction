return {
    ["StaminaUsed"] = 40,
    ["LevelRequired"] = 75,
    ["Name"] = "Tail Reaper",
    ["Keybind"] = Enum.KeyCode.C,
    ["MasteryRequired"] = 100,
    ["Cooldown"] = 10,
    ["New"] = function: 0x5a12f48f80abd26f,
}