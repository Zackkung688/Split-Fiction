return {
    ["LevelRequired"] = 125,
    ["Keybind"] = Enum.KeyCode.C,
    ["MasteryRequired"] = 150,
    ["StaminaUsed"] = 35,
    ["Hold"] = true,
    ["LimitHoldDuration"] = 4,
    ["Name"] = "Stabstorm",
    ["Cooldown"] = 10,
    ["New"] = function: 0x997d3c0ea090749f,
}