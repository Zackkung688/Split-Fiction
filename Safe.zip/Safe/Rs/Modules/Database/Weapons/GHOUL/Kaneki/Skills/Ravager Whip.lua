return {
    ["StaminaUsed"] = 25,
    ["LevelRequired"] = 175,
    ["Name"] = "Ravager Whip",
    ["Keybind"] = Enum.KeyCode.V,
    ["MasteryRequired"] = 250,
    ["Cooldown"] = 9,
    ["New"] = function: 0x336f0ef7a18322df,
}