return {
    ["StaminaUsed"] = 35,
    ["LevelRequired"] = 75,
    ["Name"] = "Dive",
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 110,
    ["Cooldown"] = 8,
    ["New"] = function: 0xb43c3d5ddab780ef,
}