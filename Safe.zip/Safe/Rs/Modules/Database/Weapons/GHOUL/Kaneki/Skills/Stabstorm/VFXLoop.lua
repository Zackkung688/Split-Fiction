return {
    ["Loop"] = function: 0x6b96ddcaa75aaeef,
    ["Stop"] = function: 0x3349b9bb541faa2f,
    ["StopAll"] = function: 0x8a2259730290fb6f,
}