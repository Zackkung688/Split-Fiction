return {
    ["StaminaUsed"] = 45,
    ["LevelRequired"] = 0,
    ["Name"] = "Lifecoil",
    ["Keybind"] = Enum.KeyCode.F,
    ["MasteryRequired"] = 0,
    ["Cooldown"] = 35,
    ["New"] = function: 0x80353ca57adad11f,
}