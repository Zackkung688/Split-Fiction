return {
    ["StaminaUsed"] = 30,
    ["LevelRequired"] = 250,
    ["Name"] = "Worm Whip",
    ["Keybind"] = Enum.KeyCode.V,
    ["MasteryRequired"] = 225,
    ["Cooldown"] = 15,
    ["New"] = function: 0x3473e8a3cf8f73bf,
}