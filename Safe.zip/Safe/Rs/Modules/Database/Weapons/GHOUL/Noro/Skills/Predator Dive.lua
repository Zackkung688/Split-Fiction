return {
    ["StaminaUsed"] = 30,
    ["LevelRequired"] = 75,
    ["Name"] = "Predator Dive",
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 110,
    ["Cooldown"] = 14,
    ["New"] = function: 0x16f5fefab503f66f,
}