return {
    ["StaminaUsed"] = 30,
    ["LevelRequired"] = 150,
    ["Name"] = "Dual Bite",
    ["Keybind"] = Enum.KeyCode.C,
    ["MasteryRequired"] = 200,
    ["Cooldown"] = 8,
    ["New"] = function: 0x87ada24a509fd5ef,
}