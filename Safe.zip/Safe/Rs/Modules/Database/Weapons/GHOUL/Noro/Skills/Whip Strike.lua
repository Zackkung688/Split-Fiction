return {
    ["StaminaUsed"] = 45,
    ["LevelRequired"] = 1,
    ["Name"] = "Whip Strike",
    ["Keybind"] = Enum.KeyCode.Z,
    ["MasteryRequired"] = 0,
    ["Cooldown"] = 7,
    ["New"] = function: 0x0f7d12193a484d2f,
}