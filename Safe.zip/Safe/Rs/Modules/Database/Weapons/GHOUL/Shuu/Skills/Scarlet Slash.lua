return {
    ["StaminaUsed"] = 40,
    ["LevelRequired"] = 100,
    ["Name"] = "Scarlet Slash",
    ["Keybind"] = Enum.KeyCode.C,
    ["MasteryRequired"] = 125,
    ["Cooldown"] = 8,
    ["New"] = function: 0x0abc7fb8c0d09b6f,
}