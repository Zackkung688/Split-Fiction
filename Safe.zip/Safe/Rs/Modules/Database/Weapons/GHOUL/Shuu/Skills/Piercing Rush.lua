return {
    ["StaminaUsed"] = 50,
    ["LevelRequired"] = 45,
    ["Name"] = "Piercing Rush",
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 75,
    ["Cooldown"] = 10,
    ["New"] = function: 0xbfb4fb76f557a86f,
}