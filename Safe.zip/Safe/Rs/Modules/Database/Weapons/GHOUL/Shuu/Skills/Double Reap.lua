return {
    ["StaminaUsed"] = 40,
    ["LevelRequired"] = 150,
    ["Name"] = "Double Reap",
    ["Keybind"] = Enum.KeyCode.V,
    ["MasteryRequired"] = 175,
    ["Cooldown"] = 12,
    ["New"] = function: 0x5c453cd58ac272ef,
}