return {
    ["StaminaUsed"] = 35,
    ["LevelRequired"] = 1,
    ["Name"] = "Impaler",
    ["Keybind"] = Enum.KeyCode.Z,
    ["MasteryRequired"] = 0,
    ["Cooldown"] = 5,
    ["New"] = function: 0xd0d57c36befe6d6f,
}