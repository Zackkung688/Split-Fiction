return {
    ["Type"] = "Bikaku",
    ["HitEffect"] = "BloodSplash",
    ["Animations"] = {
        ["M3"] = 121891198499616,
        ["M2"] = 139825328761829,
        ["Idle"] = 122931796867286,
        ["Weapon"] = {
            ["M3"] = 121891198499616,
            ["M2"] = 139825328761829,
            ["Idle"] = 122931796867286,
            ["M4"] = 128814539291936,
            ["M1"] = 130042582998198,
            ["Run"] = 101361909494022,
            ["Walk"] = 140701173372231,
        },
        ["M4"] = 128814539291936,
        ["M1"] = 130042582998198,
        ["Run"] = 101361909494022,
        ["Walk"] = 140701173372231,
    },
    ["AttackSound"] = "Woosh",
    ["AttackDelay"] = 0.45,
    ["Image"] = "rbxassetid://138144361214354",
    ["Weld"] = {
        ["Target"] = "LowerTorso",
        ["Offset"] = 0.0469999984, 0.300000012, 0.100000001, -1, 0, -8.74227766e-08, 0, 1, 0, 8.74227766e-08, 0, -1,
    },
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -5.5, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Damage"] = 11,
        ["Size"] = 9, 5, 13,
    },
    ["Stacks"] = {
        ["Healing Charge"] = {
            ["Max"] = 4,
            ["BarColor"] = 0.529412, 0, 0.00784314,
            ["ValueType"] = "NumberValue",
        },
    },
    ["MaxMastery"] = 400,
    ["Rarity"] = "Legendary",
    ["Buy"] = {
        ["ProductID"] = 3495393074,
        ["Materials"] = {
            ["Kagune Crystal"] = 100,
            ["Rin Fragment"] = 20,
            ["Bulk Fragment"] = 20,
            ["Serpent Fragment"] = 15,
            ["Rin eye"] = 3,
        },
        ["Yen"] = 2000000,
    },
}