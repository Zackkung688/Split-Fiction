return {
    ["StaminaUsed"] = 35,
    ["LevelRequired"] = 75,
    ["Name"] = "Crystal Dash",
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 100,
    ["Cooldown"] = 7,
    ["New"] = function: 0xa7d3f1fce038626f,
}