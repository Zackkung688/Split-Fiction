return {
    ["StaminaUsed"] = 20,
    ["LevelRequired"] = 1,
    ["Name"] = "Shard Shot",
    ["Keybind"] = Enum.KeyCode.Z,
    ["MasteryRequired"] = 0,
    ["Cooldown"] = 1,
    ["New"] = function: 0xb1c480d5f02c1aef,
}