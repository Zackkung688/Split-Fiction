return {
    ["StaminaUsed"] = 35,
    ["LevelRequired"] = 250,
    ["Name"] = "Skyfall Feathers",
    ["Keybind"] = Enum.KeyCode.V,
    ["Hold"] = false,
    ["MasteryRequired"] = 300,
    ["Cooldown"] = 20,
    ["New"] = function: 0xb1e5bd5c0522bdef,
}