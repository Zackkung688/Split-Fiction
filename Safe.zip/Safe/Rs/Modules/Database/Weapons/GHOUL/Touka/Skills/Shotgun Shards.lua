return {
    ["StaminaUsed"] = 35,
    ["LevelRequired"] = 125,
    ["Name"] = "Shotgun Shards",
    ["Keybind"] = Enum.KeyCode.C,
    ["MasteryRequired"] = 175,
    ["Cooldown"] = 9,
    ["New"] = function: 0x496c209f90c443ef,
}