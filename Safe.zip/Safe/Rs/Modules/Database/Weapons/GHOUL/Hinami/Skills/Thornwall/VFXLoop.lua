return {
    ["Loop"] = function: 0xb0cce022669051af,
    ["Stop"] = function: 0x0fdbf5c2175da0ef,
    ["StopAll"] = function: 0x8084c5aa581b102f,
}