return {
    ["StaminaUsed"] = 50,
    ["LevelRequired"] = 225,
    ["Name"] = "Nature Blast",
    ["Keybind"] = Enum.KeyCode.V,
    ["MasteryRequired"] = 250,
    ["Cooldown"] = 45,
    ["New"] = function: 0x6e5d683cbe0b8dcf,
}