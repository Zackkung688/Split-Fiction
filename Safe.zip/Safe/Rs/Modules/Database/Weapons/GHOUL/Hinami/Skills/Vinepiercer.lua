return {
    ["StaminaUsed"] = 35,
    ["LevelRequired"] = 75,
    ["Name"] = "Vinepiercer",
    ["Keybind"] = Enum.KeyCode.X,
    ["MasteryRequired"] = 100,
    ["Cooldown"] = 12,
    ["New"] = function: 0xbbf3d614180c06ff,
}