return {
    ["LevelRequired"] = 1,
    ["Keybind"] = Enum.KeyCode.Z,
    ["MasteryRequired"] = 0,
    ["StaminaUsed"] = 40,
    ["Hold"] = true,
    ["LimitHoldDuration"] = 6,
    ["Name"] = "Lash Flurry",
    ["Cooldown"] = 14,
    ["New"] = function: 0xbbae992104091e2f,
}