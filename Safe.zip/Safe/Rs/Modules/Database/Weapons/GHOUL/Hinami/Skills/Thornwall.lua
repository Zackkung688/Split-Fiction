return {
    ["LevelRequired"] = 150,
    ["Keybind"] = Enum.KeyCode.C,
    ["MasteryRequired"] = 200,
    ["StaminaUsed"] = 40,
    ["Hold"] = true,
    ["LimitHoldDuration"] = 6,
    ["Name"] = "Thornwall",
    ["Cooldown"] = 15,
    ["New"] = function: 0xfdfeda739bbf38af,
}