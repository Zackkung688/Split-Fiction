return {
    ["LevelRequired"] = 150,
    ["Rarity"] = "Rare",
    ["OncePerTarget"] = false,
    ["Rewards"] = {
        ["Items"] = {
            ["Rare Gacha"] = 1,
        },
        ["Exp"] = 200000,
    },
    ["QuestType"] = "BoardQuest",
    ["QuestInfo"] = "Kill 20 Bulk ghouls.",
    ["Name"] = "Shadows of Rin",
    ["Target"] = {
        [1] = "Bulk Ghoul",
    },
    ["Type"] = "Kill",
    ["OnUpdate"] = function: 0x92b1c58e8e7ccb6f,
    ["Goal"] = 20,
}