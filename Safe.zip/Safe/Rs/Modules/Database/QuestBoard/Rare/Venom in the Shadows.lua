return {
    ["LevelRequired"] = 350,
    ["Rarity"] = "Rare",
    ["OncePerTarget"] = false,
    ["Rewards"] = {
        ["Items"] = {
            ["Rare Gacha"] = 1,
        },
        ["Exp"] = 300000,
    },
    ["QuestType"] = "BoardQuest",
    ["QuestInfo"] = "Kill 20 Serpent ghouls.",
    ["Name"] = "Venom in the Shadows",
    ["Target"] = {
        [1] = "Serpent Ghoul",
    },
    ["Type"] = "Kill",
    ["OnUpdate"] = function: 0xd0f0066b454b0c6f,
    ["Goal"] = 20,
}