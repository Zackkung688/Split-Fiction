return {
    ["LevelRequired"] = 1,
    ["Rarity"] = "Common",
    ["OncePerTarget"] = false,
    ["Rewards"] = {
        ["Items"] = {
            ["Gacha"] = 1,
        },
        ["Exp"] = 1000,
    },
    ["QuestType"] = "BoardQuest",
    ["QuestInfo"] = "Kill 7 Athletes.",
    ["Name"] = "Athlete Hunt",
    ["Target"] = {
        [1] = "Athlete",
    },
    ["Type"] = "Kill",
    ["OnUpdate"] = function: 0xbec6a99e630ea56f,
    ["Goal"] = 7,
}