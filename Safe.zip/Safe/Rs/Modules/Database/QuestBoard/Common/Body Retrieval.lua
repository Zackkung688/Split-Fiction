return {
    ["LevelRequired"] = 1,
    ["Rarity"] = "Common",
    ["OncePerTarget"] = false,
    ["Rewards"] = {
        ["Items"] = {
            ["Gacha"] = 1,
        },
        ["Exp"] = 10000,
    },
    ["QuestType"] = "BoardQuest",
    ["QuestInfo"] = "Clean 30 Human bodies.",
    ["Name"] = "Body Retrieval",
    ["Target"] = {
        [1] = "Human",
        [2] = "Athlete",
    },
    ["Type"] = "Eat",
    ["OnUpdate"] = function: 0x423fae70fb7fa2af,
    ["Goal"] = 30,
}