return {
    ["LevelRequired"] = 150,
    ["Rarity"] = "Common",
    ["OncePerTarget"] = false,
    ["Rewards"] = {
        ["Items"] = {
            ["Gacha"] = 1,
        },
        ["Exp"] = 7500,
    },
    ["QuestType"] = "BoardQuest",
    ["QuestInfo"] = "Kill 15 Bulk ghouls.",
    ["Name"] = "Bulk Cleanup",
    ["Target"] = {
        [1] = "Bulk Ghoul",
    },
    ["Type"] = "Kill",
    ["OnUpdate"] = function: 0x0d210bc24116e46f,
    ["Goal"] = 15,
}