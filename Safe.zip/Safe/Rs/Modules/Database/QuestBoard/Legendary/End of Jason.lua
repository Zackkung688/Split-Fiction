return {
    ["LevelRequired"] = 200,
    ["Rarity"] = "Legendary",
    ["OncePerTarget"] = false,
    ["Rewards"] = {
        ["Items"] = {
            ["Legend Gacha"] = 1,
        },
        ["Exp"] = 250000,
    },
    ["QuestType"] = "BoardQuest",
    ["QuestInfo"] = "Kill 1 jason.",
    ["Name"] = "End of Jason",
    ["Target"] = {
        [1] = "JasonKakuja",
    },
    ["Type"] = "Kill",
    ["OnUpdate"] = function: 0xfe528d32de2cc96f,
    ["Goal"] = 1,
}