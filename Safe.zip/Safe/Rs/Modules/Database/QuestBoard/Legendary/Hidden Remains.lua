return {
    ["LevelRequired"] = 450,
    ["Rarity"] = "Legendary",
    ["OncePerTarget"] = false,
    ["Rewards"] = {
        ["Items"] = {
            ["Legend Gacha"] = 1,
        },
        ["Exp"] = 500000,
    },
    ["QuestType"] = "BoardQuest",
    ["QuestInfo"] = "Collect 15 Chests around the map.",
    ["Name"] = "Hidden Remains",
    ["Target"] = {
        [1] = "Chest",
    },
    ["Type"] = "Collect",
    ["OnUpdate"] = function: 0xd6173a4e4b464c4f,
    ["Goal"] = 15,
}