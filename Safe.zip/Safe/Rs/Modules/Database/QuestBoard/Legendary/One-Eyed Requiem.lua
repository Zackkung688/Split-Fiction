return {
    ["LevelRequired"] = 200,
    ["Rarity"] = "Legendary",
    ["OncePerTarget"] = false,
    ["Rewards"] = {
        ["Items"] = {
            ["Legend Gacha"] = 1,
        },
        ["Exp"] = 250000,
    },
    ["QuestType"] = "BoardQuest",
    ["QuestInfo"] = "Kill 1 kaneki.",
    ["Name"] = "One-Eyed Requiem",
    ["Target"] = {
        [1] = "Kaneki",
    },
    ["Type"] = "Kill",
    ["OnUpdate"] = function: 0x443ede1ee5c0260f,
    ["Goal"] = 1,
}