return {
    ["Call"] = function: 0x95409b3928c18fef,
    ["Buff"] = {
        ["Durability"] = 10,
    },
}