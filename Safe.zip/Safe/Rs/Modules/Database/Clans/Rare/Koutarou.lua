return {
    ["Call"] = function: 0x789dabb21630480f,
    ["Buff"] = {
        ["Durability"] = 5,
        ["Speed"] = 5,
    },
}