return {
    ["Call"] = function: 0x22d8f5e134987f2f,
    ["Buff"] = {
        ["Speed"] = 10,
    },
}