return {
    ["Call"] = function: 0x07496137c0cb942f,
    ["Buff"] = {
        ["Damage"] = 10,
    },
}