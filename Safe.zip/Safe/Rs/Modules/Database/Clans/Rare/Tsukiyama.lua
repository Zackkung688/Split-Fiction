return {
    ["Call"] = function: 0x5e387c0bdca00e2f,
    ["Buff"] = {
        ["Durability"] = 5,
        ["Damage"] = 5,
    },
}