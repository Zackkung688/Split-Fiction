return {
    ["Call"] = function: 0x4ddf18ecb8e83eef,
    ["Buff"] = {
    },
}