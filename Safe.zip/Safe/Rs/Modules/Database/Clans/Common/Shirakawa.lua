return {
    ["Call"] = function: 0x2b3d4715c78f9dcf,
    ["Buff"] = {
    },
}