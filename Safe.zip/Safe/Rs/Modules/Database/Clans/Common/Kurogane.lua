return {
    ["Call"] = function: 0xa899a79e0af7c2af,
    ["Buff"] = {
    },
}