return {
    ["Call"] = function: 0x2cf93198b0dec8af,
    ["Buff"] = {
    },
}