return {
    ["Call"] = function: 0xd9b6569211ea7c8f,
    ["Buff"] = {
    },
}