return {
    ["Call"] = function: 0x16e05a7f4b5b58ef,
    ["Buff"] = {
    },
}