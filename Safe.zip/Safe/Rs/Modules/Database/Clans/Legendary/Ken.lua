return {
    ["Call"] = function: 0x2adc8d79b672b5cf,
    ["Buff"] = {
        ["Dmage"] = 15,
        ["Durability"] = 5,
    },
}