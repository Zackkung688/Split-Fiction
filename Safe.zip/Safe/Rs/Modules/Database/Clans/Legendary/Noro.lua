return {
    ["Call"] = function: 0xbc5c32849350ac4f,
    ["Buff"] = {
        ["Durability"] = 15,
    },
}