return {
    ["Call"] = function: 0x04305d9f6f56296f,
    ["Buff"] = {
        ["Speed"] = 15,
    },
}