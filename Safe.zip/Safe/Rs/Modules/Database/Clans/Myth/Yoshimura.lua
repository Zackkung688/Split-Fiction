return {
    ["Call"] = function: 0x84e7e4b4d9bdb20f,
    ["Buff"] = {
        ["Durability"] = 20,
    },
}