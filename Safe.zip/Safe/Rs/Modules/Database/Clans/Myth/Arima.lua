return {
    ["Call"] = function: 0xeff5ecebba7da58f,
    ["CustomInputSkill"] = {
    },
    ["Buff"] = {
        ["Speed"] = 10,
        ["Damage"] = 15,
    },
}