return {
    ["New"] = function: 0xf533b4f6ad4141df,
    ["Cooldown"] = 20,
    ["Keybind"] = Enum.KeyCode.R,
}