return {
    ["ChasePlayer"] = true,
    ["HitEffect"] = "Punch",
    ["BaseDamage"] = 190,
    ["CorpseTime"] = 15,
    ["CustomConnection"] = function: 0x77209fe55693af5f,
    ["PlaySpawnEffect"] = true,
    ["AttackDistance"] = 12,
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -6, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Size"] = 8, 8, 12,
    },
    ["Health"] = 30000,
    ["SetCollisionGroup"] = true,
    ["Rewards"] = {
        ["Items"] = {
            ["Bulk Fragment"] = {
                ["Rate"] = 50,
                ["MaxAmount"] = 5,
            },
            ["Serpent Fragment"] = {
                ["Rate"] = 35,
                ["MaxAmount"] = 5,
            },
            ["Jason"] = {
                ["Rate"] = 1,
                ["MaxAmount"] = 1,
            },
        },
        ["LevelRequired"] = 1,
    },
    ["RespawnDelay"] = 2700,
    ["WalkSpeed"] = 20,
    ["MaxCombo"] = 5,
}