return {
    ["ChasePlayer"] = true,
    ["HitEffect"] = "BloodSplash",
    ["BaseDamage"] = 190,
    ["CorpseTime"] = 15,
    ["PlaySpawnEffect"] = true,
    ["AttackDistance"] = 12,
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -6, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Size"] = 8, 8, 12,
    },
    ["Health"] = 40000,
    ["SetCollisionGroup"] = true,
    ["Rewards"] = {
        ["Items"] = {
            ["Noro Mask"] = {
                ["Rate"] = 3,
                ["MaxAmount"] = 1,
            },
            ["Red Abyss"] = {
                ["Rate"] = 10,
                ["MaxAmount"] = 1,
            },
        },
        ["LevelRequired"] = 1,
        ["Exp"] = 35000,
        ["Yen"] = {
            ["Min"] = 75000,
            ["Max"] = 75000,
        },
        ["RC"] = 350,
    },
    ["RespawnDelay"] = 1400,
    ["WalkSpeed"] = 30,
    ["MaxCombo"] = 4,
}