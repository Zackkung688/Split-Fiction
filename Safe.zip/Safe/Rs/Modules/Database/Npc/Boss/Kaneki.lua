return {
    ["ChasePlayer"] = true,
    ["HitEffect"] = "BloodSplash",
    ["BaseDamage"] = 175,
    ["CorpseTime"] = 15,
    ["PlaySpawnEffect"] = true,
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -6, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Size"] = 8, 8, 12,
    },
    ["Health"] = 45000,
    ["SetCollisionGroup"] = true,
    ["Rewards"] = {
        ["Items"] = {
            ["Eyepatch"] = {
                ["Rate"] = 10,
                ["MaxAmount"] = 1,
            },
            ["Serpent Fragment"] = {
                ["Rate"] = 35,
                ["MaxAmount"] = 5,
            },
            ["One eyepatch"] = {
                ["Rate"] = 50,
                ["MaxAmount"] = 1,
            },
            ["Rin Fragment"] = {
                ["Rate"] = 10,
                ["MaxAmount"] = 5,
            },
        },
        ["LevelRequired"] = 1,
        ["Exp"] = 75000,
        ["Yen"] = {
            ["Min"] = 200000,
            ["Max"] = 200000,
        },
        ["RC"] = 450,
    },
    ["RespawnDelay"] = 1800,
    ["WalkSpeed"] = 33,
    ["MaxCombo"] = 4,
}