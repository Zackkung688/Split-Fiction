return {
    ["OnDied"] = function: 0x0ec720fc91ece6ef,
    ["RespawnDelay"] = 3600,
    ["CorpseTime"] = 0,
    ["Brain"] = function: 0x94b500587f05483f,
    ["PlaySpawnEffect"] = false,
    ["Health"] = 150000,
    ["Lifetime"] = 1800,
    ["WalkSpeed"] = 0,
    ["Rewards"] = {
        ["Exp"] = 50000,
    },
}