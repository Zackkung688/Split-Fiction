return {
    ["ChasePlayer"] = true,
    ["HitEffect"] = "BloodSplash",
    ["BaseDamage"] = 250,
    ["CorpseTime"] = 15,
    ["PlaySpawnEffect"] = true,
    ["AttackDistance"] = 12,
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -6, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Size"] = 8, 8, 12,
    },
    ["Health"] = 17500,
    ["SetCollisionGroup"] = true,
    ["Rewards"] = {
        ["Items"] = {
            ["Bulk Fragment"] = {
                ["Rate"] = 50,
                ["MaxAmount"] = 5,
            },
            ["Serpent Fragment"] = {
                ["Rate"] = 35,
                ["MaxAmount"] = 5,
            },
            ["Jason"] = {
                ["Rate"] = 1,
                ["MaxAmount"] = 1,
            },
        },
        ["LevelRequired"] = 1,
        ["Exp"] = 50000,
        ["Yen"] = {
            ["Min"] = 100000,
            ["Max"] = 100000,
        },
        ["RC"] = 450,
    },
    ["RespawnDelay"] = 1400,
    ["WalkSpeed"] = 30,
    ["MaxCombo"] = 5,
}