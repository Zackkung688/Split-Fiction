return {
    ["Activate"] = function: 0x2768a0d73c0ad24f,
}