return {
    ["Activate"] = function: 0xccb6c01b57f5c56f,
}