return {
    ["SetCollisionGroup"] = true,
    ["Rewards"] = {
        ["Items"] = {
        },
        ["LevelRequired"] = 1,
        ["Yen"] = {
            ["Min"] = 100,
            ["Max"] = 150,
        },
        ["Exp"] = 70,
    },
    ["Health"] = 175,
    ["RespawnDelay"] = 21,
    ["FleePlayer"] = true,
    ["CorpseTime"] = 15,
    ["WalkSpeed"] = 16,
    ["PlaySpawnEffect"] = true,
}