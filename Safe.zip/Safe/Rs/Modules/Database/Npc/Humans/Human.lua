return {
    ["SetCollisionGroup"] = true,
    ["Rewards"] = {
        ["Items"] = {
        },
        ["LevelRequired"] = 1,
        ["Yen"] = {
            ["Min"] = 50,
            ["Max"] = 100,
        },
        ["Exp"] = 35,
    },
    ["Health"] = 100,
    ["RespawnDelay"] = 21,
    ["FleePlayer"] = true,
    ["CorpseTime"] = 15,
    ["WalkSpeed"] = 12,
    ["PlaySpawnEffect"] = true,
}