return {
    ["ChasePlayer"] = true,
    ["HitEffect"] = "Punch",
    ["BaseDamage"] = 15,
    ["CorpseTime"] = 15,
    ["PlaySpawnEffect"] = true,
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -3, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Size"] = 6, 6, 9,
    },
    ["Health"] = 125,
    ["SetCollisionGroup"] = true,
    ["Rewards"] = {
        ["Items"] = {
        },
        ["LevelRequired"] = 1,
        ["Yen"] = {
            ["Min"] = 10,
            ["Max"] = 20,
        },
        ["Exp"] = 25,
    },
    ["RespawnDelay"] = 21,
    ["WalkSpeed"] = 18,
    ["MaxCombo"] = 1,
}