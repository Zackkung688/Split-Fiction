return {
    ["ChasePlayer"] = true,
    ["HitEffect"] = "BloodSplash",
    ["BaseDamage"] = 50,
    ["CorpseTime"] = 15,
    ["PlaySpawnEffect"] = true,
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -3, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Size"] = 6, 6, 9,
    },
    ["Health"] = 1450,
    ["SetCollisionGroup"] = true,
    ["Rewards"] = {
        ["Items"] = {
            ["Kagune Crystal"] = {
                ["Rate"] = 15,
                ["MaxAmount"] = 1,
            },
            ["Bulk Fragment"] = {
                ["Rate"] = 13,
                ["MaxAmount"] = 2,
            },
        },
        ["LevelRequired"] = 150,
        ["Yen"] = {
            ["Min"] = 300,
            ["Max"] = 500,
        },
        ["Exp"] = 625,
    },
    ["RespawnDelay"] = 21,
    ["WalkSpeed"] = 23,
    ["MaxCombo"] = 3,
}