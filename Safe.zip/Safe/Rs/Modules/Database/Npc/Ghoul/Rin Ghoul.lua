return {
    ["ChasePlayer"] = true,
    ["HitEffect"] = "BloodSplash",
    ["BaseDamage"] = 150,
    ["CorpseTime"] = 15,
    ["PlaySpawnEffect"] = true,
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -3, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Size"] = 6, 6, 9,
    },
    ["Health"] = 3000,
    ["SetCollisionGroup"] = true,
    ["Rewards"] = {
        ["Items"] = {
            ["Rin eye"] = {
                ["Rate"] = 1,
                ["MaxAmount"] = 1,
            },
            ["Kagune Crystal"] = {
                ["Rate"] = 30,
                ["MaxAmount"] = 1,
            },
            ["Rin Fragment"] = {
                ["Rate"] = 8,
                ["MaxAmount"] = 2,
            },
        },
        ["LevelRequired"] = 400,
        ["Yen"] = {
            ["Min"] = 1300,
            ["Max"] = 2400,
        },
        ["Exp"] = 5000,
    },
    ["RespawnDelay"] = 21,
    ["WalkSpeed"] = 26,
    ["MaxCombo"] = 3,
}