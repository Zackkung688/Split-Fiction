return {
    ["ChasePlayer"] = true,
    ["HitEffect"] = "BloodSplash",
    ["BaseDamage"] = 100,
    ["CorpseTime"] = 15,
    ["PlaySpawnEffect"] = true,
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -3, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Size"] = 6, 6, 9,
    },
    ["Health"] = 2000,
    ["SetCollisionGroup"] = true,
    ["Rewards"] = {
        ["Items"] = {
            ["Kagune Crystal"] = {
                ["Rate"] = 25,
                ["MaxAmount"] = 1,
            },
            ["Serpent Fragment"] = {
                ["Rate"] = 10,
                ["MaxAmount"] = 2,
            },
        },
        ["LevelRequired"] = 350,
        ["Yen"] = {
            ["Min"] = 800,
            ["Max"] = 1300,
        },
        ["Exp"] = 2300,
    },
    ["RespawnDelay"] = 21,
    ["WalkSpeed"] = 25,
    ["MaxCombo"] = 3,
}