return {
    ["ChasePlayer"] = true,
    ["BaseDamage"] = 0,
    ["CorpseTime"] = 6,
    ["OnM1"] = function: 0x9eda51f1d91b682f,
    ["PlaySpawnEffect"] = false,
    ["AttackDistance"] = 75,
    ["Hitbox"] = {
        ["Offset"] = 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Size"] = 0, 0, 0,
    },
    ["Health"] = 1000,
    ["ChaseRange"] = 125,
    ["Rewards"] = {
        ["LevelRequired"] = 1,
    },
    ["SetCollisionGroup"] = true,
    ["WalkSpeed"] = 20,
    ["MaxCombo"] = 1,
}