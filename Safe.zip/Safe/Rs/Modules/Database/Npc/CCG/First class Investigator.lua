return {
    ["ChasePlayer"] = true,
    ["HitEffect"] = "BloodSlash",
    ["BaseDamage"] = 195,
    ["CorpseTime"] = 15,
    ["PlaySpawnEffect"] = true,
    ["Rewards"] = {
        ["Items"] = {
            ["Quinque Shard"] = {
                ["Rate"] = 15,
                ["MaxAmount"] = 2,
            },
        },
        ["LevelRequired"] = 450,
        ["Yen"] = {
            ["Min"] = 2000,
            ["Max"] = 3000,
        },
        ["Exp"] = 8000,
    },
    ["Health"] = 3500,
    ["SetCollisionGroup"] = true,
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -5, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Size"] = 5, 5, 7,
    },
    ["RespawnDelay"] = 21,
    ["WalkSpeed"] = 29,
    ["MaxCombo"] = 4,
}