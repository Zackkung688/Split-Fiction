return {
    ["ChasePlayer"] = true,
    ["HitEffect"] = "BloodSlash",
    ["BaseDamage"] = 20,
    ["CorpseTime"] = 15,
    ["PlaySpawnEffect"] = true,
    ["Rewards"] = {
        ["Items"] = {
            ["Armor helmet"] = {
                ["Rate"] = 1,
                ["MaxAmount"] = 1,
            },
            ["Quinque Shard"] = {
                ["Rate"] = 2,
                ["MaxAmount"] = 1,
            },
        },
        ["LevelRequired"] = 50,
        ["Yen"] = {
            ["Min"] = 100,
            ["Max"] = 250,
        },
        ["Exp"] = 175,
    },
    ["Health"] = 500,
    ["SetCollisionGroup"] = true,
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -5, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Size"] = 5, 5, 7,
    },
    ["RespawnDelay"] = 21,
    ["WalkSpeed"] = 21,
    ["MaxCombo"] = 4,
}