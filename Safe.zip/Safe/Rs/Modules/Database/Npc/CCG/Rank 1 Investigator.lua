return {
    ["ChasePlayer"] = true,
    ["HitEffect"] = "BloodSlash",
    ["BaseDamage"] = 50,
    ["CorpseTime"] = 15,
    ["PlaySpawnEffect"] = true,
    ["Rewards"] = {
        ["Items"] = {
            ["Quinque Shard"] = {
                ["Rate"] = 5,
                ["MaxAmount"] = 1,
            },
        },
        ["LevelRequired"] = 250,
        ["Yen"] = {
            ["Min"] = 650,
            ["Max"] = 900,
        },
        ["Exp"] = 1100,
    },
    ["Health"] = 2000,
    ["SetCollisionGroup"] = true,
    ["Hitbox"] = {
        ["Offset"] = 0, 0, -5, 1, 0, 0, 0, 1, 0, 0, 0, 1,
        ["Size"] = 5, 5, 7,
    },
    ["RespawnDelay"] = 21,
    ["WalkSpeed"] = 25,
    ["MaxCombo"] = 4,
}