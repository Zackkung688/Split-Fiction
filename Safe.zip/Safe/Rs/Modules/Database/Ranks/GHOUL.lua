return {
    ["Initiate"] = {
        ["Reputation"] = 0,
    },
}