return {
    ["Trainee"] = {
        ["Reputation"] = 0,
    },
}